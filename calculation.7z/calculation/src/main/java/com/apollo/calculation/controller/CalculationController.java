package com.apollo.calculation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.apollo.calculation.model.Calculation;
import com.apollo.calculation.repository.CalculationRepository;

@RestController
@RequestMapping("/Calculation")
public class CalculationController {

	@Autowired
	private CalculationRepository calculationRepository;

	@PostMapping("/add")
	public Calculation add(@RequestBody Calculation calculation) {

		try {

			calculation.setResult((double) calculation.getX() + (double) calculation.getY());
			calculationRepository.save(calculation);
			return calculation;

		} catch (Exception e) {

		}
		return calculation;
	}

	@PostMapping("/substract")
	public Calculation substract(@RequestBody Calculation calculation) {

		try {

			calculation.setResult((double) calculation.getX() - (double) calculation.getY());
			calculationRepository.save(calculation);
			return calculation;

		} catch (Exception e) {

		}
		return calculation;
	}

	@PostMapping("/multiply")
	public Calculation multiply(@RequestBody Calculation calculation) {

		try {

			calculation.setResult((double) calculation.getX() * (double) calculation.getY());
			calculationRepository.save(calculation);
			return calculation;

		} catch (Exception e) {

		}
		return calculation;
	}

	@PostMapping("/divide")
	public Calculation divide(@RequestBody Calculation calculation) {

		try {

			calculation.setResult((double) calculation.getX() / (double) calculation.getY());
			calculationRepository.save(calculation);
			return calculation;

		} catch (Exception e) {

		}
		return calculation;
	}

}
