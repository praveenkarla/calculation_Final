package com.apollo.calculation.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CALCULATION")
public class Calculation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name= "X")
	private int x;
	
	@Column(name= "Y")
	private int y;
	
	@Column(name= "RESULT")
	private double result;
	
	@Column(name= "OPS")
	private String ops;

	public Calculation() {

	}

	public Calculation(int x, int y, int result, String ops) {
		super();
		this.x = x;
		this.y = y;
		this.result = result;
		this.ops = ops;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public double getResult() {
		return result;
	}

	public void setResult(double result) {
		this.result = result;
	}

	public String getOps() {
		return ops;
	}

	public void setOps(String ops) {
		this.ops = ops;
	}

}
